﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parte1
{
    class Pessoa
    {  
        public string Nome {get; set;}
        public string DataNascimento  { get; set; }
        public string EstadoCIvil { get; set; }
        public string Telefone { get; set; }

        public string CPF { get; set; }

        public bool CasaPropria { get; set; }
        public bool Veiculo { get; set; }
        public char Sexo { get; set; }

        public string Quartos { get; set; }
        public string CheckIN { get; set; }
        public string CheckOUT { get; set;}

        

    }
}
